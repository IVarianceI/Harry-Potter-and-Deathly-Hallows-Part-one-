## Social network analysis with Harry Potter Script
## MIS612 - Group 7

## Install packages
install.packages("tidyverse")
install.packages("igraph")

#load libraries
library(tidyverse)
library(igraph)

#set the working directory
setwd("C:/Users/DevPro/Dropbox/Drexel/610/R scripts/612")

#read file
talks <- read_csv("conversations.csv")
talks

#select distinct speakers
sources <- talks %>%
  distinct(Actor1) %>%
  rename(label = Actor1)

destinations <- talks %>%
  distinct(Actor2) %>%
  rename(label = Actor2)

#make nodes - merge all speakers
nodes <- full_join(sources, destinations, by = "label")

#identify each nodes with numbers
nodes <- nodes %>% rowid_to_column("id")
nodes

#make edges with weight (# of conversation)
per_route <- talks %>%  
  group_by(Actor1, Actor2) %>%
  summarise(weight = n()) %>% 
  ungroup()
per_route

#associate nodes with edges
edges <- per_route %>% 
  left_join(nodes, by = c("Actor1" = "label")) %>% 
  rename(from = id)

edges <- edges %>% 
  left_join(nodes, by = c("Actor2" = "label")) %>% 
  rename(to = id)

#select edges
edges <- select(edges, from, to, weight)
edges

#make igraph
routes_igraph <- graph_from_data_frame(d = edges, vertices = nodes, directed = FALSE)
routes_igraph

par(mar=c(0,0,0,0))

#draw graph for overall character
plot(routes_igraph,layout=layout_randomly)

#draw graph for main characters / width of edge by weight (conversation)
rgraph_simple <- routes_igraph
V(rgraph_simple)$size <- log(strength(rgraph_simple))
V(rgraph_simple)$label <- ifelse( strength(rgraph_simple)>=10, V(rgraph_simple)$label, NA)
E(rgraph_simple)$width <- log(E(rgraph_simple)$weight) + 1
plot(rgraph_simple,layout=layout_randomly)

#draw graph in circular form
plot(rgraph_simple,layout=layout_in_circle)


